<!DOCTYPE html>
<html>
<head>
    <title>Database Connection Field</title>
    <style>
        h1 {
            text-align: center;
            color: #333; /* Example color */
            font-size: 43px; /* Example font size */
            /* Add any other styles you want for the h1 tag */
        }
    </style>
</head>
<body>
    <h1>Database Connection Field</h1>

    <div style="text-align: center;">
        <a href="index.php" style="text-decoration: none;">
            <button style="display: inline-block; padding: 10px 20px; background-color: #007bff; color: #fff; border: none; cursor: pointer; border-radius: 5px;">
                Go Back
            </button>
        </a>
    </div>
</body>
</html>

