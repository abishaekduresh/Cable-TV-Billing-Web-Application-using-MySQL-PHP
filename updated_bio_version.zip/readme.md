# CABLE TV BILLING SOFTWARE

## Developemt

- Added biometric Tabular and Calandar report
- Added prompt in credit and cancel action before processing 
- App settings added SMS turn on/off toggle button
- Added passcode in profile to hassle free login without OTP
- Admin dashboard removed all except SMS credit
- Added income/expense 3inch print view
- Removed component2 code

